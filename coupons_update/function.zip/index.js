const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, UpdateCommand } = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({
    region:"us-east-1",
    endpoint:"http://host.docker.internal:4566"
});

const dynamodb = DynamoDBDocumentClient.from(client);
const tableName = "coupons";

exports.handler = async(event) => {

    const couponID = event.pathParameters.id;
    const body = JSON.parse(event.body);

    try {

        await dynamodb.send(
            new UpdateCommand({
                TableName: tableName,

                Key: {
                    id: couponID
                },

                UpdateExpression:
                "set provider_id=:provider_id, campaign_id=:campaign_id, #n=:name, discount=:discount",

                ExpressionAttributeNames: {
                    "#n": "name"
                },

                ExpressionAttributeValues: {
                    ":provider_id": body.provider_id,
                    ":campaign_id": body.campaign_id,
                    ":name": body.name,
                    ":discount": body.discount
                }
            })
        );

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Coupon updated"
            })
        };

    } catch(error) {

        return {
            statusCode: 500,
            body: error.message
        };
    }
};